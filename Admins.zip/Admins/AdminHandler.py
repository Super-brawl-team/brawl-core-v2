from Admins.Network.AdminServer import AdminServer

AdminServer(True, False).start_server()